#include <errno.h>
#include "ccapi_os_ipc.h"

cc_int32 cci_os_ipc_thread_init (void)
{
    return EINVAL;
}
void cci_os_ipc_thread_fini (void)
{
}
